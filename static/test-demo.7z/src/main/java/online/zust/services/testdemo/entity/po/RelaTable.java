package online.zust.services.testdemo.entity.po;

import lombok.Data;

/**
 * @author qcqcqc
 */
@Data
public class RelaTable {
    private Long id;
    private Long companyId;
    private Long testId;
}
