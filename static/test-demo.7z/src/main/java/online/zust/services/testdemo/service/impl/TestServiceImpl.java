package online.zust.services.testdemo.service.impl;

import online.zust.services.EnhanceService;
import online.zust.services.testdemo.entity.po.Test;
import online.zust.services.testdemo.mapper.TestMapper;
import online.zust.services.testdemo.service.TestService;
import org.springframework.stereotype.Service;

/**
 * @author qcqcqc
 */
@Service
public class TestServiceImpl extends EnhanceService<TestMapper, Test> implements TestService {
}
