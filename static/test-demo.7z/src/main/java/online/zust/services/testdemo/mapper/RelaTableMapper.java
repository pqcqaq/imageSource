package online.zust.services.testdemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import online.zust.services.testdemo.entity.po.RelaTable;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author qcqcqc
 */
@Mapper
public interface RelaTableMapper extends BaseMapper<RelaTable> {
}
