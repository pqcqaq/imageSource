package online.zust.services.testdemo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import online.zust.services.testdemo.entity.po.Company;

/**
 * @author qcqcqc
 */
public interface CompanyService extends IService<Company> {
}
