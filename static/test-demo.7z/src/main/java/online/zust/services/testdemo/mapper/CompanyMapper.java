package online.zust.services.testdemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import online.zust.services.testdemo.entity.po.Company;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author qcqcqc
 */
@Mapper
public interface CompanyMapper extends BaseMapper<Company> {
}
