package online.zust.services.testdemo.service.impl;

import online.zust.services.EnhanceService;
import online.zust.services.testdemo.entity.po.User;
import online.zust.services.testdemo.mapper.UserMapper;
import online.zust.services.testdemo.service.UserService;
import org.springframework.stereotype.Service;

/**
 * @author qcqcqc
 */
@Service
public class UserServiceImpl extends EnhanceService<UserMapper, User> implements UserService {
}
