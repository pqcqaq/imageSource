package online.zust.services.testdemo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import online.zust.services.testdemo.entity.po.Test;

/**
 * @author qcqcqc
 */
public interface TestService extends IService<Test> {
}
