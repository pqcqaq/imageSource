package online.zust.services.testdemo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import online.zust.services.testdemo.entity.po.User;

/**
 * @author qcqcqc
 */
public interface UserService extends IService<User> {
}
