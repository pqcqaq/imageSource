package online.zust.services.testdemo.service.impl;

import online.zust.services.EnhanceService;
import online.zust.services.testdemo.entity.po.Company;
import online.zust.services.testdemo.mapper.CompanyMapper;
import online.zust.services.testdemo.service.CompanyService;
import org.springframework.stereotype.Service;

/**
 * @author qcqcqc
 */
@Service
public class CompanyServiceImpl extends EnhanceService<CompanyMapper, Company> implements CompanyService {
}
