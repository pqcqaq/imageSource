package online.zust.services.testdemo.entity.po;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import online.zust.services.annotation.MtMDeepSearch;
import online.zust.services.annotation.OtMDeepSearch;
import online.zust.services.annotation.OtODeepSearch;
import online.zust.services.testdemo.service.impl.RelaTableServiceImpl;
import online.zust.services.testdemo.service.impl.TestServiceImpl;

import java.util.List;

/**
 * @author qcqcqc
 */
@Data
public class Company {
    private Long id;
    private String name;
    private Long testId;

    @TableField(exist = false)
    @OtODeepSearch(baseId = "testId", service = TestServiceImpl.class)
    private Test test;

    @TableField(exist = false)
    @MtMDeepSearch(baseId = "company_id", targetId = "testId",
            relaService = RelaTableServiceImpl.class, targetService = TestServiceImpl.class)
    private List<Test> testList;

    @OtMDeepSearch(baseId = "company_id", service = TestServiceImpl.class)
    @TableField(exist = false)
    private List<Test> tests;
}
