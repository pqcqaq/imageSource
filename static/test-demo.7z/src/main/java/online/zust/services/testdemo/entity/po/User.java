package online.zust.services.testdemo.entity.po;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import online.zust.services.annotation.OtODeepSearch;
import online.zust.services.testdemo.service.impl.CompanyServiceImpl;

/**
 * @author qcqcqc
 */
@Data
@TableName("user")
public class User {
    @TableId
    private Long id;
    private String name;
    private Long companyId;

    @OtODeepSearch(service = CompanyServiceImpl.class)
    @TableField(exist = false)
    private Company company;
}
