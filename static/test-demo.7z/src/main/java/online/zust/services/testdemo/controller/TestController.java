package online.zust.services.testdemo.controller;

import online.zust.services.testdemo.entity.po.User;
import online.zust.services.testdemo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author qcqcqc
 */
@RestController
public class TestController {

    private final UserService userService;

    @Autowired
    public TestController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/user")
    public User getUserById(@RequestParam Long id) {
        return userService.getById(id);
    }

}
