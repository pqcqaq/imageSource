package online.zust.services.testdemo.service.impl;

import online.zust.services.EnhanceService;
import online.zust.services.testdemo.entity.po.RelaTable;
import online.zust.services.testdemo.mapper.RelaTableMapper;
import online.zust.services.testdemo.service.RelaTableService;
import org.springframework.stereotype.Service;

/**
 * @author qcqcqc
 */
@Service
public class RelaTableServiceImpl extends EnhanceService<RelaTableMapper, RelaTable> implements RelaTableService {
}
