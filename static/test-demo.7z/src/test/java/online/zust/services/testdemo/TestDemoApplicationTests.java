package online.zust.services.testdemo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import online.zust.services.testdemo.entity.po.Company;
import online.zust.services.testdemo.entity.po.User;
import online.zust.services.testdemo.service.CompanyService;
import online.zust.services.testdemo.service.TestService;
import online.zust.services.testdemo.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestDemoApplicationTests {
    @Autowired
    private UserService userService;
    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void contextLoads() throws JsonProcessingException {
        // 预先查一次，创建sqlSessionFactory
        userService.getById(111);
        System.out.println("=====================================start=====================================");
        long l = System.nanoTime();
        User byId = userService.getById(111);
        long l1 = System.nanoTime();
        String x = objectMapper.writeValueAsString(byId);
        System.out.println(x);
        System.out.println("总耗时：" + (l1 - l) / 1000000 + "ms");
    }

}
